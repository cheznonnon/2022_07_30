// Nekomimi Nina
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef N_GAMECONSOLE

#include "../nonnon/project/define_unicode.c"

#endif // #ifdef N_GAMECONSOLE




#include "../nonnon/game/timegettime.c"

#include "../nonnon/game/game.c"


// [!] : PNG support

#include "../nonnon/neutral/png.c"
#include "../nonnon/game/rc.c"


#include "../nonnon/game/chara.c"
#include "../nonnon/game/input.c"
#include "../nonnon/game/sound.c"
#include "../nonnon/game/transition.c"

#include "../nonnon/game/map.c"
#include "../nonnon/game/map_chara.c"


#include "../nonnon/neutral/wav/all.c"



#include "../nonnon/project/macro.c"




n_bool
n_game_map_chara_is_block( u32 d )
{
	return ( 0 == n_game_map_prm2_get( d ) );
}




// Shared


#define N_NN_NPC_ON


#define NN_WAV_0          "N_PROJECT_SOUND_TING"
#define NN_WAV_3          "N_PROJECT_SOUND_SH"


#define N_NN_INIT_NEUTRAL ( 0 )
#define N_NN_INIT_RUNNING ( 1 )
#define N_NN_INIT_DONE    ( 2 )


#define N_NN_PLAYER_NINA ( 0 )
#define N_NN_PLAYER_NONO ( 1 )

#define N_NN_PIYO_MAX    ( 5 * 3 )
#define N_NN_NPC_MAX     ( 3 + 1 + 1 + N_NN_PIYO_MAX )		// [!] : hlift + vlift + block + piyo
#define N_NN_CHR_MAX     ( 1 + N_NN_NPC_MAX )
#define N_NN_MAP_MAX     ( 4 )
#define N_NN_BMP_MAX     ( 6 + 1 + N_NN_MAP_MAX )		// [!] : resource + worldmap + backup
#define N_NN_WAV_MAX     ( 7 )
#define N_NN_PHASE_MAX   ( 1 )

#define N_NN_CHR_PLAYER  ( 0 )
#define N_NN_CHR_HLIFT_0 ( 1 )
#define N_NN_CHR_HLIFT_1 ( 2 )
#define N_NN_CHR_HLIFT_2 ( 3 )
#define N_NN_CHR_VLIFT   ( 4 )
#define N_NN_CHR_BLOCK   ( 5 )
#define N_NN_CHR_PIYO    ( 6 )

#define N_NN_BMP_PLAYER  ( 0 )
#define N_NN_BMP_LIFT    ( 1 )
#define N_NN_BMP_BLOCK   ( 2 )
#define N_NN_BMP_PIYO    ( 3 )
#define N_NN_BMP_BALLOON ( 4 )
#define N_NN_BMP_WORLD   ( 5 )
#define N_NN_BMP_BACKUP  ( 6 )

#define N_NN_SND_PHASE   ( 0 )
#define N_NN_SND_BRAKE   ( 1 )
#define N_NN_SND_WALK    ( 2 )
#define N_NN_SND_JUMP    ( 3 )
#define N_NN_SND_DOKAN   ( 4 )
#define N_NN_SND_LANDING ( 5 )
#define N_NN_SND_PIPE    ( 6 )

#define N_NN_MAP_BACK    ( 0 )
#define N_NN_MAP_MAIN    ( 1 )
#define N_NN_MAP_FG_1    ( 2 )
#define N_NN_MAP_FG_2    ( 3 )




// System

typedef struct {

	n_bool is_first;

	n_type_gfx zoom;
	n_type_gfx csx,csy;
	n_type_gfx unit;
	n_type_gfx unit_mx;
	n_type_gfx unit_my;
	n_type_gfx unit_duck;

	n_type_gfx srcx_dash;
	n_type_gfx srcx_stop;
	n_type_gfx srcx_jump;
	n_type_gfx srcx_duck;
	n_type_gfx srcx_face;
	n_type_gfx srcx_back;
	n_type_gfx srcx_ride;

	n_type_gfx dash_min;
	n_type_gfx dash_max;
	n_type_gfx dash_step;
	n_type_gfx dash_frame;
	n_type_gfx dash_msec;
	n_type_gfx dash_slide;

	n_type_gfx jump_max;
	n_type_gfx jump_step;
	n_type_gfx jump_flow;


	n_game_chara      chr[ N_NN_CHR_MAX ];
	n_game_map_chara  mch[ N_NN_CHR_MAX ];
	n_bmp             bmp[ N_NN_BMP_MAX ];
	n_game_sound      snd[ N_NN_WAV_MAX ];
	n_game_map        map[ N_NN_MAP_MAX ];

	n_bmp             bmp_backup[ N_NN_MAP_MAX ];

	int               init;
	int               phase;
	int               event;
	int               player, player_prev;

	n_bool            duck;
	n_bool            dokan;
	n_bool            walk_step;
	n_bool            riding;
	n_bool            balloon;
	n_bool            worldmap;

	n_bool            turn;
	int               turn_frame;

	n_game_input      input;

	int               dokan_axl;
	n_bool            dokan_main;
	n_bool            dokan_snd;

	int               riding_piyo;

	n_bool            sine_init;
	n_type_real       sine_step[ 100 ];
	int               sine_index;
	int               sine_max;

	n_type_real       transition_percent;

} n_nn;

#define n_nn_zero( p ) n_memory_zero( p, sizeof( n_nn ) )




static n_nn nn;




// internal
void
n_game_map_chara_jump_sine( n_game_map_chara *mc )
{

	if ( n_game_map_safemode )
	{
		if ( mc    == NULL ) { return; }
		if ( mc->c == NULL ) { return; }
	}


	n_game_chara *c = mc->c;

	if ( mc->jump == N_GAME_MAP_CHARA_JUMP_OFF )
	{

		if ( n_game_refresh_is_off() )
		{
//n_win_debug_count( game.hwnd );

			mc->redraw = n_true;

			mc->jump     = N_GAME_MAP_CHARA_JUMP_ON_RISE;
			mc->jump_cur = 0;


			c->srcx = mc->jump_srcx;


			nn.sine_index = 0;


			if ( nn.sine_init == n_false )
			{

				nn.sine_init = n_true;


				n_type_real step = 0;
				int         i    = 0;
				n_posix_loop
				{

					nn.sine_step[ i ] = mc->jump_max * fabs( sin( 2.0 * M_PI * step ) );

					i++;

					step += 0.0075;
					if ( step > 0.25 ) { nn.sine_max = i; break; }
				}
//n_game_hwndprintf_literal( " %d ", nn.sine_max );

				i = nn.sine_max - 1;
				n_posix_loop
				{

					nn.sine_step[ i ] = nn.sine_step[ i ] - nn.sine_step[ i - 1 ];

					i--;
					if ( i < 1 ) { break; }
				}

				i = 0;
				n_posix_loop
				{break;

					n_posix_debug_literal( " %f ", nn.sine_step[ i ] );

					i++;
					if ( i >= nn.sine_max ) { break; }
				}
			}

		}

	} else
	if ( mc->jump == N_GAME_MAP_CHARA_JUMP_ON_RISE )
	{

		if ( nn.sine_index < nn.sine_max )
		{
//n_win_debug_count( game.hwnd );

			mc->redraw = n_true;

			n_game_map_chara_fit( mc, (n_type_gfx) nn.sine_step[ nn.sine_index ], N_GAME_MAP_CHARA_UP );

			nn.sine_index++;

		} else {

			mc->jump = N_GAME_MAP_CHARA_JUMP_ON_FALL;

		}

	}


	return;
}




void
n_nn_metric( n_nn *p )
{

	n_posix_char *cmdline = n_win_commandline_new();
	n_string_commandline_option_literal( "-nn", cmdline );


	n_type_gfx desktop_sx, desktop_sy; n_win_desktop_size( &desktop_sx, &desktop_sy );

	p->zoom = n_posix_max_n_type_gfx( 1, desktop_sx / 1280 );

	{

		n_posix_char *cmdline = n_win_commandline_new();

		n_string_commandline_option_literal( "-nn", cmdline );

		if ( n_posix_atoi( cmdline ) )
		{
			p->zoom = n_posix_max( 1, n_posix_atoi( cmdline ) );
		}

		n_string_free( cmdline );

	}

	n_string_path_free( cmdline );

	p->csx        = n_posix_max_n_type_gfx( 320, (n_type_gfx) ( (n_type_real) desktop_sx * 0.4 ) );
	p->csy        = n_posix_max_n_type_gfx( 240, (n_type_gfx) ( (n_type_real) desktop_sy * 0.4 ) );
	p->unit       =  32 * 2 * p->zoom;
	p->unit_mx    =   4 * 2 * p->zoom;
	p->unit_my    =   4 * 2 * p->zoom;
	p->unit_duck  =  16 * 2 * p->zoom;


	// Character Default

	p->srcx_dash  = p->unit * 0;
	p->srcx_stop  = p->unit * 6;
	p->srcx_jump  = p->unit * 5;
	p->srcx_duck  = p->unit * 4;
	p->srcx_face  = p->unit * 7;
	p->srcx_back  = p->unit * 8;
	p->srcx_ride  = p->unit * 0; // [!] : something is needed


	// [!] : 60fps : +1 for tuning

	int move = 1;

	p->dash_min   = p->unit      / ( 16 + move );
	p->dash_max   = p->dash_min  * (  3 +    0 );
	p->dash_step  = 1;
	p->dash_frame = 4;
	p->dash_msec  = 100 * p->zoom;
 
	p->jump_max   = p->unit      * (  4 + move );
	p->jump_step  = p->jump_max  / ( 10        ); p->jump_step -= p->jump_step / 2;
	p->jump_flow  = p->jump_step / (  3 + move );


	// Charcter Init

	{

		int i = 0;
		n_posix_loop
		{

			p->mch[ i ].m      = &p->map[ N_NN_MAP_MAIN ];
			p->mch[ i ].c      = &p->chr[ i ];

			p->mch[ i ].redraw = n_true;
			p->mch[ i ].lr     = N_GAME_MAP_CHARA_LEFT;

			i++;
			if ( i >= N_NN_CHR_MAX ) { break; }
		}

	}

	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];

	mc->dash             = 0;
	mc->dash_cur         = 0;
	mc->dash_min         = p->dash_min;
	mc->dash_max         = p->dash_max;
	mc->dash_step        = p->dash_step;
	mc->dash_srcx        = p->srcx_dash;
	mc->dash_frame       = p->dash_frame;
	mc->dash_frame_msec  = p->dash_msec;
	mc->dash_frame_timer = 0;
	mc->slip_srcx        = p->srcx_stop;

	mc->jump             = 0;
	mc->jump_cur         = 0;
	mc->jump_max         = p->jump_max;
	mc->jump_step        = p->jump_step;
	mc->jump_srcx        = p->srcx_jump;


	n_game_chara_bmp( mc->c, &game.bmp, &p->bmp[ N_NN_BMP_PLAYER ], NULL, 0 );

	{
		n_type_gfx sx = p->unit;
		n_type_gfx sy = p->unit * 2;
		n_type_gfx mx = p->unit_mx;
		n_type_gfx my = p->unit_my;

		n_game_chara_src( mc->c, 0,0,sx,sy, mx,my );
	}


#ifdef N_NN_NPC_ON

	p->mch[ N_NN_CHR_HLIFT_0 ].dash_step = p->dash_min * 4;
	p->mch[ N_NN_CHR_HLIFT_1 ].dash_step = p->dash_min * 2;
	p->mch[ N_NN_CHR_HLIFT_2 ].dash_step = p->dash_min * 1;
	p->mch[ N_NN_CHR_VLIFT   ].dash_step = p->dash_min * 1;

	n_game_chara_bmp( p->mch[ N_NN_CHR_HLIFT_0 ].c, &game.bmp, &p->bmp[ N_NN_BMP_LIFT ], NULL, 0 );
	n_game_chara_bmp( p->mch[ N_NN_CHR_HLIFT_1 ].c, &game.bmp, &p->bmp[ N_NN_BMP_LIFT ], NULL, 0 );
	n_game_chara_bmp( p->mch[ N_NN_CHR_HLIFT_2 ].c, &game.bmp, &p->bmp[ N_NN_BMP_LIFT ], NULL, 0 );
	n_game_chara_bmp( p->mch[ N_NN_CHR_VLIFT   ].c, &game.bmp, &p->bmp[ N_NN_BMP_LIFT ], NULL, 0 );

	{

		n_type_gfx sx = p->unit * 2;
		n_type_gfx sy = p->unit / 2;
		n_type_gfx mx = 0;
		n_type_gfx my = 0;

		n_game_chara_src( p->mch[ N_NN_CHR_HLIFT_0 ].c, 0,0,sx,sy, mx,my );
		n_game_chara_src( p->mch[ N_NN_CHR_HLIFT_1 ].c, 0,0,sx,sy, mx,my );
		n_game_chara_src( p->mch[ N_NN_CHR_HLIFT_2 ].c, 0,0,sx,sy, mx,my );
		n_game_chara_src( p->mch[ N_NN_CHR_VLIFT   ].c, 0,0,sx,sy, mx,my );

	}


	n_game_chara_bmp( p->mch[ N_NN_CHR_BLOCK ].c, &game.bmp, &p->bmp[ N_NN_BMP_BLOCK ], NULL, 0 );

	{

		n_type_gfx sx = p->unit * 2;
		n_type_gfx sy = p->unit * 2;
		n_type_gfx mx = 0;
		n_type_gfx my = 0;

		n_game_chara_src( p->mch[ N_NN_CHR_BLOCK ].c, 0,0,sx,sy, mx,my );

	}


	{

		n_type_gfx sx = p->unit;
		n_type_gfx sy = p->unit;
		n_type_gfx mx = p->unit_mx;
		n_type_gfx my = p->unit_my;

		int i = 0;
		n_posix_loop
		{

			n_game_chara *c =   p->mch[ N_NN_CHR_PIYO + i ].c;
			n_bmp        *b  = &p->bmp[ N_NN_BMP_PIYO ];

			n_game_chara_bmp( c, &game.bmp, b, NULL, 0 );

			n_game_chara_src( c, 0,0,sx,sy, mx,my );

			i++;
			if ( i >= N_NN_PIYO_MAX ) { break; }
		}

	}

#endif // #ifdef N_NN_NPC_ON


	p->is_first = n_true;


	return;
}

void
n_nn_scaler_big( n_nn *p, n_bmp *bmp )
{

	// [Needed] : complicated : a frame is important

	n_bmp tmp; n_bmp_zero( &tmp ); n_bmp_carboncopy( bmp, &tmp );
	n_bmp_flush_replacer( &tmp, n_bmp_trans, n_bmp_white_invisible );
	n_bmp_scaler_big( &tmp, p->zoom );

	n_bmp_transparent_onoff( bmp, n_false );

	n_bmp_flush_replacer( bmp, n_bmp_rgb( 0,255,255 ), n_bmp_white_invisible );
	n_bmp_flush_replacer( bmp, n_bmp_trans           , n_bmp_white_invisible );

	n_bmp_scaler_big_pixelart( bmp, p->zoom );

	n_bmp_transcopy_no_finalize( bmp, &tmp, 0,0,N_BMP_SX( bmp ),N_BMP_SY( bmp ), 0,0 );

	n_bmp_free_fast( bmp ); n_bmp_alias( &tmp, bmp );

	n_bmp_flush_replacer( bmp, n_bmp_white_invisible,            n_bmp_trans );

//if ( i == 0 ) { n_bmp_save_literal( bmp, "ret.bmp" ); }

	n_bmp_transparent_onoff( bmp,  n_true );


	return;
}




// Components

#include "./rule.c"
#include "./tool.c"




void
n_nn_autofocus( n_nn *p, n_game_map_chara *mc, int offscreen )
{

	if ( n_game_map_safemode )
	{
		if ( mc    == NULL ) { return; }
		if ( mc->m == NULL ) { return; }
		if ( mc->c == NULL ) { return; }
	}


	n_game_map   *m = mc->m;
	n_game_chara *c = mc->c;


	n_game_map_chara_loop( mc, offscreen );

	if ( nn.player == N_NN_PLAYER_NINA )
	{
//n_game_hwndprintf_literal( " %d %d ", c->y, m->y );

		m->x = c->x + ( ( c->sx - game.sx ) / 2 );
		m->y = c->y + ( ( c->sy - game.sy ) / 2 );

	} else {

		m->x = c->x + ( ( c->sx - game.sx ) / 2 );
		m->y = c->y + ( ( c->sy - game.sy ) / 2 );

	}


	return;
}

void
n_nn_duck( n_nn *p, n_bool onoff, n_bool is_forced )
{

	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];


	if ( is_forced == n_false )
	{
		if ( mc->jump != N_GAME_MAP_CHARA_JUMP_OFF ) { return; }
	}


	if ( onoff == n_false )
	{

		if ( p->duck == n_false ) { return; }


		mc->redraw = n_true;
		p->duck    = n_false;


		mc->c->srcy -= p->unit_duck;
		mc->c->y    -= p->unit_duck;
		mc->c->sy   += p->unit_duck;

		if ( mc->c->srcx == p->srcx_duck )
		{
			mc->c->srcx = p->srcx_dash;
		}

	} else {

		if ( p->duck ) { return; }


		mc->redraw = n_true;
		p->duck    = n_true;


		mc->c->srcy += p->unit_duck;
		mc->c->y    += p->unit_duck;
		mc->c->sy   -= p->unit_duck;

		if ( mc->c->srcx != p->srcx_duck )
		{
			mc->c->srcx = p->srcx_duck;
		}

	}


	return;
}

void
n_nn_dash( n_nn *p )
{

	if ( n_false == n_game_refresh_is_off() ) { return; }

	if ( p->dokan ) { return; }

	if ( p->riding >= N_NN_CHR_PIYO )
	{
/*
		// [!] : currently conflict with chick's direction

		if ( n_game_input_loop( &p->input, VK_LEFT  ) )
		{
			p->mch[ N_NN_CHR_PLAYER ].lr = N_GAME_MAP_CHARA_LEFT;
		}
		if ( n_game_input_loop( &p->input, VK_RIGHT ) )
		{
			p->mch[ N_NN_CHR_PLAYER ].lr = N_GAME_MAP_CHARA_RIGHT;
		}
*/
		return;
	}


	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];


	// [Mechanism] : input mutex
	//
	// 	when pressing L and R at the same time
	//	take the newest direction smoothly

	static int mc_lr = N_GAME_MAP_CHARA_NOMOVE;

	static u32 timer = 0;

	if ( n_game_timer( &timer, 100 ) )
	{

		const int input_nil = ( 0 << 0 );
		const int input_l   = ( 1 << 0 );
		const int input_r   = ( 1 << 1 );
		const int input_all = input_l | input_r;

		static int p_lr = ( 0 << 0 );
		static int   lr = ( 0 << 0 );


		// [Needed] : Gamepad : slip effect is hard to function without this

		lr = input_nil;
		if ( n_game_input_loop( &p->input, VK_LEFT  ) ) { lr |= input_l; }
		if ( n_game_input_loop( &p->input, VK_RIGHT ) ) { lr |= input_r; }

		if ( lr == input_nil ) { mc_lr = N_GAME_MAP_CHARA_NOMOVE; }

		if ( lr == input_all )
		{
			lr = p_lr;
			if ( lr == input_l ) { lr = input_r; } else { lr = input_l; }
		} else {
			p_lr = lr;
		}


		// [!] : convert to n_game_map_chara.lr

		if ( lr == input_l ) { mc_lr = N_GAME_MAP_CHARA_LEFT;  } else
		if ( lr == input_r ) { mc_lr = N_GAME_MAP_CHARA_RIGHT; }

	}


	// Turn-Around : Detection

	n_bool turn = ( ( mc_lr != N_GAME_MAP_CHARA_NOMOVE )&&( mc->lr != mc_lr ) );


	// Ducking

	n_bool duck = ( n_game_input_loop( &p->input, VK_DOWN ) );

	n_nn_duck( p, duck, n_false );


	static n_bool duck_onoff = n_true;

	if ( duck_onoff != duck ) { p->dash_slide = mc->dash_cur * 2; }

	duck_onoff = duck;


	// Stopping

	if ( mc_lr == N_GAME_MAP_CHARA_NOMOVE )
	{

		p->walk_step = n_false;

		if ( duck == n_false ) { n_game_map_chara_stop( mc ); }

		return;
	}


	// Dash

	mc->dash = ( n_game_input_loop( &p->input, 'Z' ) );

	n_type_gfx p_srcx = mc->c->srcx;

	if ( duck == n_false )
	{
		n_game_map_chara_dash( mc, mc_lr );
/*
		if ( mc->jump )
		{
			n_game_map_chara_fit
			(
				mc,
				mc->dash_step + ( mc->dash_step * mc->dash_cur / 3 * 2 ),
				mc->lr
			);
		}
*/
	}


	// [Needed] : [ LR + Accel + NoDuck + NoBrake ]

	if ( mc->jump != N_GAME_MAP_CHARA_JUMP_OFF ) { return; }


	if ( duck )
	{

		// [Needed] : [ LR + NoBrake ]

		mc->lr = mc_lr;


		// The Famous Plumber's Sliding

		p->dash_slide -= p->zoom;
		if ( p->dash_slide < 0 ) { p->dash_slide = 0; }
//n_game_hwndprintf_literal( " %d ", p->dash_slide );

		if ( mc->lr == N_GAME_MAP_CHARA_LEFT  ) { n_game_map_chara_fit( mc, p->dash_slide, N_GAME_MAP_CHARA_LEFT  ); } else
		if ( mc->lr == N_GAME_MAP_CHARA_RIGHT ) { n_game_map_chara_fit( mc, p->dash_slide, N_GAME_MAP_CHARA_RIGHT ); }

	} else
	if ( mc->lr != mc_lr )
	{

		n_game_sound_loop( &p->snd[ N_NN_SND_BRAKE ] );

	} else {

		if ( p_srcx != mc->c->srcx )
		{
			if ( p->walk_step )
			{
				p->walk_step = n_false;
			} else {
				p->walk_step = n_true;
				n_game_sound_loop( &p->snd[ N_NN_SND_WALK ] );
			}
		}


		int msec = n_posix_min( p->dash_msec, mc->dash_cur * 5 );
		mc->dash_frame_msec = p->dash_msec - msec;


		// [!] : turn-around needs enough frames

		if ( ( turn )&&( p->turn == n_false ) ) { p->turn = n_true; }

		if ( p->turn )
		{

			mc->redraw = n_true;

			if ( mc->lr == N_GAME_MAP_CHARA_LEFT  ) { mc->c->srcx = p->srcx_back; } else
			if ( mc->lr == N_GAME_MAP_CHARA_RIGHT ) { mc->c->srcx = p->srcx_face; }

			p->turn_frame++;
			if ( p->turn_frame >= 2 ) { p->turn_frame = p->turn = 0; }


			if ( mc->lr == N_GAME_MAP_CHARA_LEFT  ) { n_game_map_chara_fit( mc, 0, N_GAME_MAP_CHARA_LEFT  ); } else
			if ( mc->lr == N_GAME_MAP_CHARA_RIGHT ) { n_game_map_chara_fit( mc, 0, N_GAME_MAP_CHARA_RIGHT ); }

		}

	}


	return;
}

void
n_nn_jump( n_nn *p )
{

	if ( n_false == n_game_refresh_is_off() ) { return; }

	if ( p->dokan ) { return; }


	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];
//n_game_hwndprintf_literal( " %d ", mc->jump );


	if ( n_game_input_loop( &p->input, 'X' ) )
	{

		n_nn_duck( p, n_false, n_false );


		if ( mc->jump == N_GAME_MAP_CHARA_JUMP_OFF )
		{

			if ( n_game_refresh_is_off() )
			{
				n_game_sound_loop( &p->snd[ N_NN_SND_JUMP ] );
			}


			n_game_map_chara_jump_sine( mc );


			// Shakeoff

			if ( p->riding )
			{
				n_game_map_chara_fit( mc, mc->c->my, N_GAME_MAP_CHARA_UP );
			}

		} else
		if ( mc->jump == N_GAME_MAP_CHARA_JUMP_ON_RISE )
		{
//n_game_hwndprintf_literal( " RISE " );

			mc->jump_step = p->jump_step;

			n_game_map_chara_jump_sine( mc );

		} else
		if ( mc->jump == N_GAME_MAP_CHARA_JUMP_ON_FALL )
		{
//n_game_hwndprintf_literal( " FALL " );

			// Flowy-effect

			mc->jump_step = p->jump_flow;

		}

	} else {

		mc->jump_step = p->jump_step;

		if ( mc->jump == N_GAME_MAP_CHARA_JUMP_ON_RISE )
		{
			mc->jump = N_GAME_MAP_CHARA_JUMP_ON_FALL;
		}

	}


	return;
}

void
n_nn_gravity( n_nn *p )
{

	if ( n_false == n_game_refresh_is_off() ) { return; }

	if ( p->dokan ) { return; }


	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];


	n_type_gfx p_srcx   = mc->c->srcx;
	n_bool     p_redraw = mc->redraw;


	// [Mechanism] : two n_nn_duck()s in this module
	//
	//	a : prevent redraw error (upper half will be disappeared)
	//	b : duck directly when landed

	n_nn_duck( p, n_false, n_false );


	if ( mc->jump == N_GAME_MAP_CHARA_JUMP_ON_FALL )
	{
		if ( n_game_input_loop( &p->input, VK_DOWN ) )
		{
			mc->jump_step *= 2;
		}
	}


	mc->redraw = n_false;
	n_game_map_chara_gravity( mc );


	static n_bool shaker = n_false;
	static u32    timer  = 0;

	if (
		( mc->redraw )
		&&
		( mc->jump == N_GAME_MAP_CHARA_JUMP_OFF )
	)
	{

		if ( mc->jump_step > p->jump_step )
		{
			shaker = n_true;
			timer  = n_posix_tickcount();
		}

		mc->jump_step = p->jump_step;

		if ( shaker == n_false )
		{
			n_game_sound_loop( &p->snd[ N_NN_SND_WALK    ] );
		} else {
			n_game_sound_loop( &p->snd[ N_NN_SND_LANDING ] );
		}

	}

	if ( shaker )
	{

		int n = mc->jump_step;
		int v = N_GAME_INPUT_XINPUT_VIBRATE_MAX;

		if ( n_game_timer( &timer, 200 ) )
		{
			shaker = n_false;
			n      = 0;
			v      = 0;
		}

		n_game_screenshaker( n );
		n_game_input_XInput_vibrate( &p->input, v, v );

	}


	if ( p->riding )
	{
		p->riding   = n_false;
		mc->c->srcx = p_srcx;
	}

	if ( n_game_input_loop( &p->input, VK_DOWN ) ) { n_nn_duck( p, n_true, n_false ); }


	mc->redraw |= p_redraw;
	return;
}

void
n_nn_dokan( n_nn *p )
{

//n_game_hwndprintf_literal( "%d", n_nn_rule_chip( p ) );


	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];


	if ( p->dokan == n_false )
	{

		if (
			( n_game_input_loop( &p->input, VK_DOWN ) )
			&&
			( n_nn_rule_is_dokan( p ) )
		)
		{

			p->dokan   = n_true;
			p->balloon = n_false;

/*
n_game_hwndprintf_literal
(
	" %d %d %d %d ",
	n_game_map_chip_get( n_nn_rule_data_map( p, &p->map[ N_NN_MAP_FG_2 ] ) ),
	n_game_map_prm1_get( n_nn_rule_data_map( p, &p->map[ N_NN_MAP_FG_2 ] ) ),
	n_game_map_prm2_get( n_nn_rule_data_map( p, &p->map[ N_NN_MAP_FG_2 ] ) ),
	n_game_map_prm3_get( n_nn_rule_data_map( p, &p->map[ N_NN_MAP_FG_2 ] ) )
);
*/
			int map = n_nn_rule_is_dokan_left_right( p );
//n_game_hwndprintf_literal( " %d ", map );

			if ( map == N_NN_RULE_IS_DOKAN_LR_LEFT )
			{
//n_game_hwndprintf_literal( " Left " );
				n_posix_loop
				{
					map = n_nn_rule_is_dokan_left_right( p );
					if ( map == N_NN_RULE_IS_DOKAN_LR_RIGHT ) { break; }
					mc->c->x++;
				}
			} else
			if ( map == N_NN_RULE_IS_DOKAN_LR_RIGHT )
			{
//n_game_hwndprintf_literal( " Right " );
				n_posix_loop
				{
					map = n_nn_rule_is_dokan_left_right( p );
					if ( map == N_NN_RULE_IS_DOKAN_LR_LEFT ) { break; }
					mc->c->x--;
				}
			}


//n_game_hwndprintf_literal( " %d ", n_nn_rule_chip( p ) );

			if ( n_nn_rule_is_dokan_main( p ) )
			{
				p->dokan_axl++;
				if ( p->dokan_axl >= 3 ) { p->dokan_axl = 3; }

				p->dokan_main = n_true;

				n_nn_graychip( p, n_true );
			} else {
				p->dokan_axl = 2;
			}


			n_game_sound_loop( &p->snd[ N_NN_SND_PIPE ] );
			p->dokan_snd = n_true;

		} else {

			p->balloon = n_nn_rule_is_dokan( p );

			if ( p->balloon ) { mc->redraw = n_true; }

			return;

		}

	}


	if ( p->dokan_main )
	{
		mc->c->y += p->dash_min * p->dokan_axl;
		if ( mc->c->y >= p->map[ N_NN_MAP_MAIN ].sx ) { mc->c->y = 0; }
	} else {
		mc->c->y += p->dash_min * p->dokan_axl;
		if ( mc->c->y >= p->map[ N_NN_MAP_MAIN ].sx ) { mc->c->y = 0; }
	}


	if ( n_nn_rule_is_empty( p ) )
	{
//n_win_debug_count( game.hwnd );

		if ( p->dokan_main )
		{
			n_nn_graychip( p, n_false );
		}

		p->dokan = p->dokan_main = n_false;

		mc->jump = N_GAME_MAP_CHARA_JUMP_ON_FALL;

		n_nn_duck( p, n_false, n_true );

		mc->c->srcx = p->srcx_jump;

	} else {

		mc->c->srcx = p->srcx_duck;

		if ( n_nn_rule_is_dokan_exit( p ) )
		{
			n_game_sound_stop( &p->snd[ N_NN_SND_DOKAN ] );
			n_game_sound_loop( &p->snd[ N_NN_SND_PIPE ] );
		} else
		if ( p->dokan_main )
		{
			// [!] : n_game_sound_timer() is heavy

			if ( n_game_sound_timer( &p->snd[ N_NN_SND_PIPE ] ) )
			{
				p->dokan_snd = n_false;
			}

			if ( p->dokan_snd == n_false )
			{
				if ( n_game_sound_timer( &p->snd[ N_NN_SND_DOKAN ] ) )
				{
					n_game_sound_loop( &p->snd[ N_NN_SND_DOKAN ] );
				}
			}
		}

	}


	mc->redraw = n_true;
	return;
}

void
n_nn_draw( n_nn *p )
{

	// Init

	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];
	n_game_map       *bg = &p->map[ N_NN_MAP_BACK ];
	n_game_map       *mg = &p->map[ N_NN_MAP_MAIN ];
	n_game_map       *f1 = &p->map[ N_NN_MAP_FG_1 ];
	n_game_map       *f2 = &p->map[ N_NN_MAP_FG_2 ];

	if ( p->dokan_main ) { f2 = mg; }


	n_nn_autofocus( p, mc, N_GAME_MAP_CHARA_LOOP_LOOP );


	{

		//n_game_map *m  = mg;
		//n_game_hwndprintf_literal( "X %ld/%ld : Y %ld/%ld", m->x, m->sx, m->y, m->sy );
		//n_game_hwndprintf_literal( "Map : X %ld : Y %ld", m->chip_sx, m->chip_sy );

		//n_game_hwndprintf_literal( "X %d : Y %d : LR %d", mc->c->x, mc->c->y, mc->lr );
		//n_game_hwndprintf_literal( "Dash %ld : Jump %ld : Duck %d", mc->dash_cur, mc->jump, p->duck );
		//n_game_hwndprintf_literal( "Walk Frame %lu msec", mc->dash_frame_msec );

	}


	// Background / Sky

	bg->mode = mg->mode & ~N_GAME_MAP_MODE_TRANS;
	bg->x    = mg->x;
	bg->y    = mg->y;

	n_game_map_draw( bg, 0, n_false );


	// Middleground / Main

	n_game_map_draw( mg, 0, n_true );


//n_game_hwndprintf_literal( " %d ", p->riding );

	if ( p->dokan == n_false )
	{

		int i = 1;
		n_posix_loop
		{

			if ( p->riding != i )
			{
				n_game_map_chara_draw( &p->mch[ i ] );
			}

			i++;
			if ( i >= N_NN_CHR_MAX ) { break; }
		}

	}

	n_game_map_chara_draw( &p->mch[ 0 ] );

	if ( p->riding != 0 )
	{
		n_game_map_chara_draw( &p->mch[ p->riding ] );
	}


	n_nn_balloon( p );


	// Foreground / Overlay

	f1->mode = mg->mode;
	f1->x    = mg->x;
	f1->y    = mg->y;

	n_game_map_draw( f1, 0, n_true );


	f2->mode = mg->mode;
	f2->x    = mg->x;
	f2->y    = mg->y;

	n_game_map_draw( f2, 0, n_true );


	n_nn_worldmap( p, n_false );


	n_game_refresh_on();
	return;
}

void
n_nn_mainscreen( n_nn *p, n_bmp *bmp )
{

	int i = 0;
	n_posix_loop
	{

		p->mch[ i ].redraw  = n_true;
		p->mch[ i ].c->main = bmp;

		i++;
		if ( i >= N_NN_CHR_MAX ) { break; }
	}


	i = 0;
	n_posix_loop
	{

		p->map[ i ].main = bmp;

		i++;
		if ( i >= N_NN_MAP_MAX ) { break; }
	}


	return;
}

void
n_nn_start( n_nn *p )
{

	if ( p->init == N_NN_INIT_DONE ) { return; }

	if ( n_game_refresh_is_on() ) { return; }


	static n_bmp bmp_old, bmp_new;
	static int   fx_type;


	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];


	if ( p->init == N_NN_INIT_NEUTRAL )
	{

		n_game_sound_loop( &p->snd[ N_NN_SND_PHASE ] );


		p->init = N_NN_INIT_RUNNING;


		// Phase 1

		n_bmp_carboncopy( &game.bmp, &bmp_old );
		n_bmp_carboncopy( &game.bmp, &bmp_new );


		// Phase 2

		n_nn_rule_phase_load( p, &bmp_new );


		mc->redraw = n_true;

		n_nn_rule_autoset( p, N_NN_CHR_PLAYER );

		mc->c->y += mc->c->my;

#ifdef N_NN_NPC_ON

		n_nn_rule_autoset( p, N_NN_CHR_HLIFT_0 );
		n_nn_rule_autoset( p, N_NN_CHR_HLIFT_1 );
		n_nn_rule_autoset( p, N_NN_CHR_HLIFT_2 );
		n_nn_rule_autoset( p, N_NN_CHR_VLIFT   );
		n_nn_rule_autoset( p, N_NN_CHR_BLOCK   );

		int i = 0;
		n_posix_loop
		{

			n_game_map_chara *npc_mc  = &p->mch[ N_NN_CHR_PIYO + i ];
			n_bmp            *bmp_map = &mc->m->map;


			npc_mc->redraw = n_true;
			mc->dash_frame = N_BMP_SX( npc_mc->c->chara ) / p->unit;


			// [!] : find position : heavy in large map

//n_game_map_chara_set( npc_mc, 124,124 );

			int ii = 0;
			n_posix_loop
			{//break;

				n_type_gfx x = n_game_random( N_BMP_SX( bmp_map ) );
				n_type_gfx y = n_game_random( N_BMP_SY( bmp_map ) );

				u32 number; n_bmp_ptr_get_fast( bmp_map, x,y, &number );

				if ( n_false == n_game_map_chara_is_block( number ) )
				{
					n_game_map_chara_set( npc_mc, x,y );
					break;
				}


				ii++;
				if ( ii >= 5 )
				{
					x = mc->c->x / npc_mc->m->unit_sx;
					y = mc->c->y / npc_mc->m->unit_sx;
					n_game_map_chara_set( npc_mc, x,y );
					break;
				}
			}


			i++;
			if ( i >= N_NN_PIYO_MAX ) { break; }
		}

#endif // #ifdef N_NN_NPC_ON


		// Phase 3

		n_nn_mainscreen( p, &bmp_new );

		n_game_map_chara_autofocus( &p->mch[ N_NN_CHR_PLAYER ], N_GAME_MAP_CHARA_LOOP_LOOP );

		n_nn_draw( p );


		// Phase 4

             	fx_type = n_nn_rule_event2transition( p );

		{

			n_type_gfx x = mc->c->x - mc->m->x;
			n_type_gfx y = mc->c->y - mc->m->y;

			x += ( mc->c->sx / 2 );
			y += ( mc->c->sy / 2 );

			n_game_transition_circle_x = x;
			n_game_transition_circle_y = y;

		}

	}


	if ( n_game_transition( &game.bmp, &bmp_old, &bmp_new, 1000, &p->transition_percent, fx_type ) )
	{

		p->init = N_NN_INIT_DONE;

		n_nn_mainscreen( p, &game.bmp );

		n_bmp_free( &bmp_old );
		n_bmp_free( &bmp_new );

		p->is_first = n_false;

	}


	n_game_refresh_on();
	return;
}




void
n_nn_init( n_nn *p )
{

	// Global

	n_bmp_safemode = n_false;

	game.fps = 60;
	n_nn_metric( p );


	// System

	n_game_title_literal( "+++ Nekomimi Nina +++" );

	game.sx    = p->csx;
	game.sy    = p->csy;
	game.color = n_bmp_black;

	n_game_dwm_off();


	if ( n_true )
	{
		n_game_window_resizable();
	} else {
		n_game_window_fixed();
		if ( IsZoomed( game.hwnd ) ) { ShowWindow( game.hwnd, SW_RESTORE ); }
	}


	// [x] : compatibility hell
	//
	//	Sega Saturn-like pad has A,B,C for inner to outer in order
	//	PS-like pad has Triangle(0) Circle(1) X(2) Square(3)
	//
	//	3DS "New Super Mario Bros. 2"-like assignment

	n_game_input_zero( &p->input );
	n_game_input_init( &p->input, 0 );
	n_game_input_vk2udlr_default( &p->input );
	n_game_input_vk2button( &p->input, 'Z',   0 ); // Dash
	n_game_input_vk2button( &p->input, 'X',   1 ); // Jump
	n_game_input_vk2button( &p->input, 'X',   2 ); // Jump
	n_game_input_vk2button( &p->input, 'Z',   3 ); // Dash
	n_game_input_vk2button( &p->input, VK_F3, 4 ); // Map On/Off


	// Init

	int i = 0;
	n_posix_loop
	{

		n_bmp_zero( &p->bmp[ i ] );

		i++;
		if ( i >= N_NN_BMP_MAX ) { break; }
	}

	i = 0;
	n_posix_loop
	{

		n_posix_char str[ 100 ];
		n_posix_sprintf_literal( str, "NN_BMP_%d", i );

		n_game_rc_load_png2bmp( &p->bmp[ i ], str );

		n_nn_scaler_big( p, &p->bmp[ i ] );


		i++;
		if ( i >= N_NN_BMP_MAX ) { break; }
	}


	n_game_sound_bulk_zero( p->snd, N_NN_WAV_MAX );

	n_game_sound_init_literal( &p->snd[ 0 ], game.hwnd,  NN_WAV_0  ); n_wav_smoother( &p->snd[ 0 ].wav );
	n_game_sound_init_literal( &p->snd[ 1 ], game.hwnd, "NN_WAV_1" ); n_wav_smoother( &p->snd[ 1 ].wav );
	n_game_sound_init_literal( &p->snd[ 2 ], game.hwnd, "NN_WAV_2" ); n_wav_smoother( &p->snd[ 2 ].wav );
	n_game_sound_init_literal( &p->snd[ 3 ], game.hwnd,  NN_WAV_3  ); n_wav_smoother( &p->snd[ 3 ].wav );
	n_game_sound_init_literal( &p->snd[ 4 ], game.hwnd, "NN_WAV_4" ); n_wav_smoother( &p->snd[ 4 ].wav );
	n_game_sound_init_literal( &p->snd[ 5 ], game.hwnd, "NN_WAV_5" ); n_wav_smoother( &p->snd[ 5 ].wav );
	n_game_sound_init_literal( &p->snd[ 6 ], game.hwnd, "NN_WAV_6" ); n_wav_smoother( &p->snd[ 6 ].wav );


	return;
}

void
n_nn_loop( n_nn *p )
{

	if ( p->is_first )
	{
		if ( n_game_refresh_is_resize() ) { return; }
	}


	n_game_map_chara *mc = &p->mch[ N_NN_CHR_PLAYER ];


	if ( p->init != N_NN_INIT_DONE )
	{

		n_nn_start( p );

		return;
	}


	if ( n_game_input_loop( &p->input, VK_F1 ) )
	{

		n_game_sound_loop( &p->snd[ N_NN_SND_PHASE ] );


		if ( p->player == N_NN_PLAYER_NINA )
		{
			p->player = N_NN_PLAYER_NONO;
		} else {
			p->player = N_NN_PLAYER_NINA;
		}
		n_nn_player_change( p );


		mc->redraw = n_true;
		n_posix_sleep( 200 );

	} else
	if ( n_game_input_loop( &p->input, VK_F2 ) )
	{

		p->event = ( p->event + 1 ) % N_NN_RULE_WARP_MAX;
		p->phase = ( p->phase + 1 ) % N_NN_RULE_PHASE_MAX;


		p->init = N_NN_INIT_NEUTRAL;

		n_posix_sleep( 200 );

		return;

	} else
	if ( n_game_input_loop( &p->input, VK_F3 ) )
	{

		if ( p->worldmap == n_false ) { p->worldmap = n_true; } else { p->worldmap = n_false; }

		n_nn_worldmap( p, n_true );

		n_game_sound_loop( &p->snd[ N_NN_SND_JUMP ] );
		n_posix_sleep( 200 );

		mc->redraw = n_true;

	}


	// [!] : order is important

	n_nn_dash   ( p );
	n_nn_jump   ( p );
	n_nn_gravity( p );
	n_nn_dokan  ( p );

//n_game_hwndprintf_literal( " %d ", mc->jump );


#ifdef N_NN_NPC_ON

	n_nn_npc_dash( p, N_NN_CHR_HLIFT_0 );
	n_nn_npc_dash( p, N_NN_CHR_HLIFT_1 );
	n_nn_npc_dash( p, N_NN_CHR_HLIFT_2 );
	n_nn_npc_jump( p, N_NN_CHR_VLIFT   );
	n_nn_npc_dash( p, N_NN_CHR_BLOCK   );
	n_nn_npc_piyo( p, N_NN_CHR_PIYO    );

#endif // #ifdef N_NN_NPC_ON


	if (
		( n_game_input_loop( &p->input, VK_UP ) )
		&&
		( n_nn_rule_is_warp( p ) )
	)
	{

		if ( mc->jump == N_GAME_MAP_CHARA_JUMP_OFF )
		{

			n_nn_duck( p, n_false, n_false );


			mc->redraw  = n_true;
			mc->c->srcx = p->srcx_back;

			n_nn_draw( p );

			mc->c->srcx = p->srcx_face;
			if ( mc->lr == N_GAME_MAP_CHARA_LEFT )
			{
				mc->lr = N_GAME_MAP_CHARA_RIGHT;
			} else {
				mc->lr = N_GAME_MAP_CHARA_LEFT;
			}

		}


		p->event = n_nn_rule_event( p );
		p->phase = 0;


		if ( n_nn_rule_is_neko( p ) )
		{
			p->player = N_NN_PLAYER_NONO;
		} else {
			p->player = N_NN_PLAYER_NINA;
		}
		n_nn_player_change( p );


		p->init = N_NN_INIT_NEUTRAL;

		return;
	}




	if ( n_game_refresh_is_off() )
	{

		n_bool redraw = n_false;

		int i = 0;
		n_posix_loop
		{

			if ( i != N_NN_CHR_PLAYER )
			{
				p->mch[ i ].redraw &= n_game_map_chara_onscreen( &p->mch[ i ] );
			}

			redraw |= p->mch[ i ].redraw;

			i++;
			if ( i >= N_NN_CHR_MAX ) { break; }
		}


		// [Needed] : mc_player will disappear

		redraw |= p->worldmap;

		if ( redraw )
		{
			mc->redraw = n_true;
			n_nn_draw( p );
		}

	} else
	if ( n_game_refresh_is_resize() )
	{

		mc->redraw = n_true;

		p->csx = game.sx;
		p->csy = game.sy;

		if ( p->worldmap ) { n_nn_worldmap( p, n_true ); }

		n_nn_draw( p );

	}


	return;
}

void
n_nn_exit( n_nn *p )
{

	int i;


	i = 0;
	n_posix_loop
	{

		n_bmp_free( &p->bmp[ i ] );

		i++;
		if ( i >= N_NN_BMP_MAX ) { break; }
	}


	i = 0;
	n_posix_loop
	{

		n_game_sound_exit( &p->snd[ i ] );

		i++;
		if ( i >= N_NN_WAV_MAX ) { break; }
	}


	i = 0;
	n_posix_loop
	{

		n_game_map_exit( &p->map[ i ] );

		i++;
		if ( i >= N_NN_MAP_MAX ) { break; }
	}


	n_game_input_exit( &p->input );


	n_nn_zero( p );


	return;
}




#ifndef N_GAMECONSOLE

void
n_game_init( void )
{

	n_nn_zero( &nn );
	n_nn_init( &nn );


	return;
}

void
n_game_loop( void )
{

	if ( n_win_is_input( VK_F5 ) )
	{
		n_nn_exit( &nn );
		n_nn_init( &nn );
		n_game_reset();
	}

	n_nn_loop( &nn );


	return;
}

void
n_game_exit( void )
{

	n_nn_exit( &nn );


	return;
}

#endif // #ifndef N_GAMECONSOLE


// Nonnon Game Console
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#include "../nonnon/project/define_unicode.c"




//#define N_MEMORY_DEBUG




#include "../nonnon/game/timegettime.c"


#define N_GAME_WAKE
#include "../nonnon/game/game.c"

#include "../nonnon/game/click.c"


#include "../nonnon/com/IShellLink.c"




// [Needed] : shared

#include "../nonnon/neutral/ini.c"
#include "../nonnon/neutral/png.c"

#include "../nonnon/win32/gdi.c"

#include "../nonnon/project/macro.c"




#define N_GAMECONSOLE


#define N_GAMECONSOLE_ICON_OFFSET_HUNYAPIYO2 (  2 )
#define N_GAMECONSOLE_ICON_OFFSET_FREECELL   ( 10 )
#define N_GAMECONSOLE_ICON_OFFSET_SPIDER     (  9 )


#include "../cr2/cr2.c"
#include "../hunyapiyo2/hunyapiyo2.c"
#include "../hunyapiyo3/hunyapiyo3.c"
#include "../lm2/lm2.c"
#include "../nfreecell/nfreecell.c"
#include "../ngame/ngame.c"
#include "../nn/nn.c"
#include "../nnrpg/nekomimi_nina_rpg.c"
#include "../nspider/nspider.c"




#define N_GAMECONSOLE_NAME_CR2        n_posix_literal( "CAR-RACE 2" )
#define N_GAMECONSOLE_NAME_HUNYAPIYO2 n_posix_literal( "hunyapiyo2" )
#define N_GAMECONSOLE_NAME_HUNYAPIYO3 n_posix_literal( "hunyapiyo3" )
#define N_GAMECONSOLE_NAME_LM2        n_posix_literal( "LINE MASHER 2" )
#define N_GAMECONSOLE_NAME_NFREECELL  n_posix_literal( "Nonnon Freecell" )
#define N_GAMECONSOLE_NAME_NGAME      n_posix_literal( "Nonnon Game" )
#define N_GAMECONSOLE_NAME_NN         n_posix_literal( "Nekomimi Nina" )
#define N_GAMECONSOLE_NAME_NNRPG      n_posix_literal( "Nekomimi Nina RPG" )
#define N_GAMECONSOLE_NAME_NSPIDER    n_posix_literal( "Nonnon Spider" )

#define N_GAMECONSOLE_CMD_CR2         n_posix_literal( "-cr2" )
#define N_GAMECONSOLE_CMD_HUNYAPIYO2  n_posix_literal( "-hunyapiyo2" )
#define N_GAMECONSOLE_CMD_HUNYAPIYO3  n_posix_literal( "-hunyapiyo3" )
#define N_GAMECONSOLE_CMD_LM2         n_posix_literal( "-lm2" )
#define N_GAMECONSOLE_CMD_NFREECELL   n_posix_literal( "-nfreecell" )
#define N_GAMECONSOLE_CMD_NGAME       n_posix_literal( "-ngame" )
#define N_GAMECONSOLE_CMD_NN          n_posix_literal( "-nn" )
#define N_GAMECONSOLE_CMD_NNRPG       n_posix_literal( "-nnrpg" )
#define N_GAMECONSOLE_CMD_NSPIDER     n_posix_literal( "-nspider" )

#define N_GAMECONSOLE_ID_NONE         ( 0 )
#define N_GAMECONSOLE_ID_CR2          ( 1 )
#define N_GAMECONSOLE_ID_HUNYAPIYO2   ( 2 )
#define N_GAMECONSOLE_ID_HUNYAPIYO3   ( 3 )
#define N_GAMECONSOLE_ID_LM2          ( 4 )
#define N_GAMECONSOLE_ID_NFREECELL    ( 5 )
#define N_GAMECONSOLE_ID_NGAME        ( 6 )
#define N_GAMECONSOLE_ID_NN           ( 7 )
#define N_GAMECONSOLE_ID_NNRPG        ( 8 )
#define N_GAMECONSOLE_ID_NSPIDER      ( 9 )




static int gameconsole_mode = N_GAMECONSOLE_ID_NONE;




LRESULT CALLBACK
n_gameconsole_wndproc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CREATE :

		n_project_darkmode();

		n_project_dialog_info( hwnd, n_posix_literal( "Welcome!" ) );

		return -1;

	break;

	case WM_CLOSE :

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch

	return DefWindowProc( hwnd, msg, wparam, lparam );
}

n_bool
n_game_wake( void )
{

	n_posix_char *cmdline = n_win_commandline_new();

	n_bool ret = n_false;

	if ( n_string_path_commandline_option_literal( "-cr2"       , cmdline, n_false ) )
	{
		gameconsole_mode = N_GAMECONSOLE_ID_CR2;
	} else
	if ( n_string_path_commandline_option_literal( "-hunyapiyo2", cmdline, n_false ) )
	{
		gameconsole_mode = N_GAMECONSOLE_ID_HUNYAPIYO2;
	} else
	if ( n_string_path_commandline_option_literal( "-hunyapiyo3", cmdline, n_false ) )
	{
		gameconsole_mode = N_GAMECONSOLE_ID_HUNYAPIYO3;
	} else
	if ( n_string_path_commandline_option_literal( "-lm2"       , cmdline, n_false ) )
	{
		gameconsole_mode = N_GAMECONSOLE_ID_LM2;
	} else
	if ( n_string_path_commandline_option_literal( "-nfreecell" , cmdline, n_false ) )
	{
		gameconsole_mode = N_GAMECONSOLE_ID_NFREECELL;
	} else
	if ( n_string_path_commandline_option_literal( "-ngame"     , cmdline, n_false ) )
	{
		gameconsole_mode = N_GAMECONSOLE_ID_NGAME;
	} else
	if ( n_string_path_commandline_option_literal( "-nn"        , cmdline, n_false ) )
	{
		gameconsole_mode = N_GAMECONSOLE_ID_NN;
	} else
	if ( n_string_path_commandline_option_literal( "-nnrpg"     , cmdline, n_false ) )
	{
		gameconsole_mode = N_GAMECONSOLE_ID_NNRPG;
	} else
	if ( n_string_path_commandline_option_literal( "-nspider"   , cmdline, n_false ) )
	{
		gameconsole_mode = N_GAMECONSOLE_ID_NSPIDER;
	} else {

		n_project_shortcut( N_GAMECONSOLE_NAME_CR2,        N_GAMECONSOLE_CMD_CR2,        N_GAMECONSOLE_ID_CR2        );
		n_project_shortcut( N_GAMECONSOLE_NAME_HUNYAPIYO2, N_GAMECONSOLE_CMD_HUNYAPIYO2, N_GAMECONSOLE_ID_HUNYAPIYO2 );
		n_project_shortcut( N_GAMECONSOLE_NAME_HUNYAPIYO3, N_GAMECONSOLE_CMD_HUNYAPIYO3, N_GAMECONSOLE_ID_HUNYAPIYO3 );
		n_project_shortcut( N_GAMECONSOLE_NAME_LM2,        N_GAMECONSOLE_CMD_LM2,        N_GAMECONSOLE_ID_LM2        );
		n_project_shortcut( N_GAMECONSOLE_NAME_NFREECELL,  N_GAMECONSOLE_CMD_NFREECELL,  N_GAMECONSOLE_ID_NFREECELL  );
		n_project_shortcut( N_GAMECONSOLE_NAME_NGAME,      N_GAMECONSOLE_CMD_NGAME,      N_GAMECONSOLE_ID_NGAME      );
		n_project_shortcut( N_GAMECONSOLE_NAME_NN,         N_GAMECONSOLE_CMD_NN,         N_GAMECONSOLE_ID_NN         );
		n_project_shortcut( N_GAMECONSOLE_NAME_NNRPG,      N_GAMECONSOLE_CMD_NNRPG,      N_GAMECONSOLE_ID_NNRPG      );
		n_project_shortcut( N_GAMECONSOLE_NAME_NSPIDER,    N_GAMECONSOLE_CMD_NSPIDER,    N_GAMECONSOLE_ID_NSPIDER    );

		n_explorer_refresh( n_true );

		n_win_main( NULL, n_gameconsole_wndproc );

		ret = n_true;

	}

	n_string_path_free( cmdline );


	return ret;
}

void
n_game_init( void )
{

	// Applets

	n_cr2_zero( &cr2 );
	n_hunyapiyo2_zero( &hunyapiyo2 );
	n_hunyapiyo3_zero( &hunyapiyo3 );
	n_lm2_zero( &lm2 );
	n_freecell_zero( &freecell );
	n_ngame_zero( &ngame );
	n_nn_zero( &nn );
	n_nnrpg_zero( &nnrpg );
	n_spider_zero( &spider );


	// System

	switch( gameconsole_mode )
	{

		case N_GAMECONSOLE_ID_CR2 :
			n_cr2_init( &cr2 );
			game.icon = n_posix_literal( "MAIN_ICON_CR2" );
		break;

		case N_GAMECONSOLE_ID_HUNYAPIYO2 :
			n_hunyapiyo2_init( &hunyapiyo2 );
			game.icon = n_posix_literal( "MAIN_ICON_HUNYAPIYO2" );
		break;

		case N_GAMECONSOLE_ID_HUNYAPIYO3 :
			n_hunyapiyo3_init( &hunyapiyo3 );
			game.icon = n_posix_literal( "MAIN_ICON_HUNYAPIYO3" );
		break;

		case N_GAMECONSOLE_ID_LM2 :
			n_lm2_init( &lm2 );
			game.icon = n_posix_literal( "MAIN_ICON_LM2" );
		break;

		case N_GAMECONSOLE_ID_NFREECELL :
			n_freecell_init( &freecell );
			game.icon = n_posix_literal( "MAIN_ICON_NFREECELL" );
		break;

		case N_GAMECONSOLE_ID_NGAME :
			n_ngame_init( &ngame );
			game.icon = n_posix_literal( "MAIN_ICON_NGAME" );
		break;

		case N_GAMECONSOLE_ID_NN :
			n_nn_init( &nn );
			game.icon = n_posix_literal( "MAIN_ICON_NN" );
		break;

		case N_GAMECONSOLE_ID_NNRPG :
			n_nnrpg_init( &nnrpg );
			game.icon = n_posix_literal( "MAIN_ICON_NNRPG" );
		break;

		case N_GAMECONSOLE_ID_NSPIDER :
			n_spider_init( &spider );
			game.icon = n_posix_literal( "MAIN_ICON_NSPIDER" );
		break;

	}


	return;
}

void
n_game_loop( void )
{

	switch( gameconsole_mode )
	{

		case N_GAMECONSOLE_ID_CR2 :
			n_cr2_loop( &cr2 );
		break;

		case N_GAMECONSOLE_ID_HUNYAPIYO2 :
			n_hunyapiyo2_loop( &hunyapiyo2 );
		break;

		case N_GAMECONSOLE_ID_HUNYAPIYO3 :
			n_hunyapiyo3_loop( &hunyapiyo3 );
		break;

		case N_GAMECONSOLE_ID_LM2 :
			n_lm2_loop( &lm2 );
		break;

		case N_GAMECONSOLE_ID_NFREECELL :
			n_freecell_loop( &freecell );
		break;

		case N_GAMECONSOLE_ID_NGAME :
			n_ngame_loop( &ngame );
		break;

		case N_GAMECONSOLE_ID_NN :
			n_nn_loop( &nn );
		break;

		case N_GAMECONSOLE_ID_NNRPG :
			n_nnrpg_loop( &nnrpg );
		break;

		case N_GAMECONSOLE_ID_NSPIDER :
			n_spider_loop( &spider );
		break;

	}


	return;
}

void
n_game_exit( void )
{

	n_cr2_exit( &cr2 );
	n_hunyapiyo2_exit( &hunyapiyo2 );
	n_hunyapiyo3_exit( &hunyapiyo3 );
	n_lm2_exit( &lm2 );
	n_freecell_exit( &freecell );
	n_ngame_exit( &ngame );
	n_nn_exit( &nn );
	n_nnrpg_exit( &nnrpg );
	n_spider_exit( &spider );


	return;
}


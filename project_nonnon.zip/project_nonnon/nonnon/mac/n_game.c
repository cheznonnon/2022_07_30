// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonGame
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonGame"
//	3 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_game display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause
//		d : Xcode integrity bug : remake a project from scratch




#ifndef _H_NONNON_MAC_NONNON_GAME
#define _H_NONNON_MAC_NONNON_GAME




#import <Cocoa/Cocoa.h>


#include "_mac.c"
#include "image.c"




#define N_MAC_GAME_SX 320
#define N_MAC_GAME_SY 240

#define N_MAC_GAME_FPS 30

#define N_MAC_GAME_KEY_INPUT_U ( 1 )
#define N_MAC_GAME_KEY_INPUT_D ( 2 )
#define N_MAC_GAME_KEY_INPUT_L ( 4 )
#define N_MAC_GAME_KEY_INPUT_R ( 8 )



@interface NonnonGame : NSView
@end


@interface NonnonGame ()
@end


@implementation NonnonGame {

	n_bmp      canvas;

	n_type_gfx obj_x;
	n_type_gfx obj_y;
	n_type_gfx obj_size;
	
	BOOL       refresh;

	int        key;

}


- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{
		n_bmp_zero( &canvas );
		n_bmp_new( &canvas, N_MAC_GAME_SX, N_MAC_GAME_SY );

		obj_x    =  0;
		obj_y    =  0;
		obj_size = 32;

		refresh = TRUE;

		n_mac_timer_init( self, @selector( n_timer_method ), 1000 / N_MAC_GAME_FPS );
	}


	return self;
}


- (void) n_mac_game_canvas_resize:(NSWindow*)window width:(n_type_gfx)sx height:(n_type_gfx)sy
{

	n_bmp_new( &canvas, sx, sy );

	NSSize size = NSMakeSize( sx,sy );

	[window setContentMinSize:size];
	[window setContentMaxSize:size];

	NSRect rect = NSMakeRect( 0,0,sx,sy );
	[self setFrame:rect];

	[window setContentSize:size];

	[window display];

}


- (BOOL) isFlipped
{
	return YES;
}


- (void)n_timer_method
{
	if ( refresh )
	{
		[self display];
	}
}


- (void)drawRect:(NSRect)rect
{
//NSLog( @"drawRect" );

	//n_bmp_flush( &canvas, n_bmp_rgb( n_random_range( 255 ),n_random_range( 255 ),n_random_range( 255 ) ) );
	NSImage *img = n_mac_image_nbmp2nsimage( &canvas );
	
	[img drawInRect:rect];

/*
NSGraphicsContext *context = [NSGraphicsContext currentContext];
CGRect             cg_rect = CGRectMake( 0, 0, img.size.width, img.size.height );
NSRect             imgrect = NSRectFromCGRect( cg_rect );
CGImageRef         ref     = [img CGImageForProposedRect:&imgrect context:context hints:nil];

CGContextRef cg_ctx = [[NSGraphicsContext currentContext] CGContext];
CGContextDrawImage( cg_ctx, imgrect, ref );
*/

}


- (void)keyDown:(NSEvent *)event
{
//NSLog( @"%d", event.keyCode );


	BOOL redraw = FALSE;

	switch( event.keyCode ) {

	case 126 :
//NSLog( @"Up" );

		key |= N_MAC_GAME_KEY_INPUT_U;

		redraw = TRUE;

	break;

	case 125:
//NSLog( @"Down" );

		key |= N_MAC_GAME_KEY_INPUT_D;

		redraw = TRUE;

	break;

	case 123:
//NSLog( @"Left" );

		key |= N_MAC_GAME_KEY_INPUT_L;

		redraw = TRUE;

	break;

	case 124:
//NSLog( @"Right" );

		key |= N_MAC_GAME_KEY_INPUT_R;

		redraw = TRUE;

	break;

	} // switch
	

	if ( redraw )
	{

		n_type_gfx p_x = obj_x;
		n_type_gfx p_y = obj_y;

		const n_type_gfx step = 4;
		
		if ( key & N_MAC_GAME_KEY_INPUT_U )
		{
			obj_y += step;
		}
		
		if ( key & N_MAC_GAME_KEY_INPUT_D )
		{
			obj_y -= step;
		}
		
		if ( key & N_MAC_GAME_KEY_INPUT_L )
		{
			obj_x -= step;
		}
		
		if ( key & N_MAC_GAME_KEY_INPUT_R )
		{
			obj_x += step;
		}
	
	
		n_bmp_box( &canvas,   p_x,   p_y, obj_size, obj_size, n_bmp_black );
		n_bmp_box( &canvas, obj_x, obj_y, obj_size, obj_size, n_bmp_rgb_mac( 0,200,255 ) );


		refresh = TRUE;

	}

}

- (void)keyUp:(NSEvent *)event
{
//NSLog( @"%d", event.keyCode );

	switch( event.keyCode ) {

	case 126 :
//NSLog( @"Up" );

		key &= ~N_MAC_GAME_KEY_INPUT_U;

	break;

	case 125:
//NSLog( @"Down" );

		key &= ~N_MAC_GAME_KEY_INPUT_D;

	break;

	case 123:
//NSLog( @"Left" );

		key &= ~N_MAC_GAME_KEY_INPUT_L;

	break;

	case 124:
//NSLog( @"Right" );

		key &= ~N_MAC_GAME_KEY_INPUT_R;

	break;

	} // switch

}


- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );
}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	n_type_gfx p_x = obj_x;
	n_type_gfx p_y = obj_y;

	obj_x = [theEvent locationInWindow].x - ( obj_size / 2 );
	obj_y = [theEvent locationInWindow].y - ( obj_size / 2 );

	n_bmp_box( &canvas,   p_x,   p_y, obj_size, obj_size, n_bmp_black );
	n_bmp_box( &canvas, obj_x, obj_y, obj_size, obj_size, n_bmp_rgb_mac( 0,200,255 ) );

	refresh = TRUE;
}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog(@"mouseDragged");
}

- (void)scrollWheel:(NSEvent *)theEvent
{
//NSLog(@"scrollWheel");
}

@end




#endif // _H_NONNON_MAC_NONNON_GAME



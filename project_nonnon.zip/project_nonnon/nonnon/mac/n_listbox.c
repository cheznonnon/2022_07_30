// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSView (Custom View) to NonnonListbox
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonListbox"
//	3 : call _n_list.delegate_doubleclick = self; at awakeFromNib
//	4 : modify behavior


// [!] : trouble shooter
//
//	[ drawRect is not called at redraw ]
//
//		a : call [_n_list display];
//		b : see your @property and connect(DnD) to UI on the Xib canvas
//		c : layer may cause




#ifndef _H_NONNON_MAC_NONNON_LISTBOX
#define _H_NONNON_MAC_NONNON_LISTBOX




#import <Cocoa/Cocoa.h>


#include "../neutral/bmp/ui/roundframe.c"
#include "../neutral/txt.c"


#include "_mac.c"
#include "image.c"




@interface NonnonListbox : NSView

@property (nonatomic,assign) id delegate_doubleclick;

@end


@interface NonnonListbox ()

@property CGFloat  n_focus;
@property n_txt   *n_txt;

@end


@implementation NonnonListbox {

	NSFont  *font;
	CGSize   font_size;
	CGFloat  scroll;
	CGPoint  pt;
	CGPoint  pt_press;

}


@synthesize delegate_doubleclick;


@synthesize n_focus;
@synthesize n_txt;




- (instancetype)initWithCoder:(NSCoder *)coder
{
//NSLog( @"initWithCoder" );

	self = [super initWithCoder:coder];
	if ( self )
	{
		// [x] : not visible
		//array = [[NSMutableArray alloc] init];

		font      = [NSFont fontWithName:@"Helvetica" size:14];
		font_size = n_mac_image_text_pixelsize( @"a", font );
		scroll    =  0;
		n_focus   = -1;
	}
	
	return self;
}


- (BOOL) isFlipped
{
	return YES;
}


- (void) n_reset
{
	scroll  =  0;
	n_focus = -1;
}


- (void) n_scroll_clamp
{

	CGFloat page   = self.frame.size.height / font_size.height;
	CGFloat txt_sy = n_txt->sy;
//NSLog( @"%f %f", page, txt_sy );

	if ( txt_sy <= 1 )
	{
		scroll = 0;
	} else
	if ( page <= txt_sy )
	{
		if ( fabs( page ) ) { page -= 1.0; }

		txt_sy -= page;

		if ( scroll <       0 ) { scroll =      0; }
		if ( scroll >= txt_sy ) { scroll = txt_sy; }
	} else {
		scroll = 0;
	}

}


- (void)drawRect:(NSRect)rect
{
//NSLog( @"drawRect" );

//NSLog( @"%lld", n_test_txt.sy );


	[self n_scroll_clamp];


	NSColor *nscolor_text  = [NSColor textColor];
	u32        color_bg    = n_mac_nscolor2argb( [NSColor textBackgroundColor] );
	u32        color_fg    = n_mac_nscolor2argb( nscolor_text );
	u32        color_frame = n_bmp_blend_pixel( color_bg, color_fg, 0.25 );
	u32       color_stripe = n_bmp_blend_pixel( color_bg, color_fg, 0.05 );
	NSColor *nscolor_text_normal    = nscolor_text;
	NSColor *nscolor_text_highlight = [NSColor controlHighlightColor];
	NSColor *nscolor_stripe         = n_mac_argb2nscolor( color_stripe );


	n_type_gfx sx = (n_type_gfx) rect.size.width;
	n_type_gfx sy = (n_type_gfx) rect.size.height;

	n_bmp frame; n_bmp_zero( &frame ); n_bmp_new_fast( &frame, sx,sy );
	n_bmp_flush( &frame, n_bmp_black_invisible );

	{
		n_bmp_flush_roundrect( &frame, color_bg, 8 );

		NSImage *img = n_mac_image_nbmp2nsimage( &frame );
		[img drawInRect:rect];
	}


	// [!] : n_txt rendering engine

	NSMutableDictionary *attr = [NSMutableDictionary dictionary];
	[attr setObject:font forKey:NSFontAttributeName ];

	CGFloat o = 6;

	NSRect r = NSMakeRect( o, o, rect.size.width - ( o * 2 ), 0 );
	CGSize s = font_size;

	r.size.height = s.height;

	CGFloat max_sy = rect.size.height - ( o * 2 );

	n_type_int i = scroll;
//NSLog( @"%f %lld", scroll, n_mac_listbox_txt.sy );
	while( 1 )
	{//break;

		NSString *text = n_mac_str2nsstring( n_txt_get( n_txt, i ) );
		if ( ( text.length != 0 )&&( n_focus == i ) )
		{
			[attr setObject:nscolor_text_highlight forKey:NSForegroundColorAttributeName];
		} else {
			[attr setObject:nscolor_text_normal    forKey:NSForegroundColorAttributeName];
		}

		if ( ( text.length != 0 )&&( n_focus == i ) )
		{
			[[NSColor controlAccentColor] set];
			[NSBezierPath fillRect:r];
		} else
		if ( ( i % 2 ) == 1 )
		{
			[nscolor_stripe set];
			[NSBezierPath fillRect:r];
		}

		if ( i < n_txt->sy )
		{
			[text drawInRect:r withAttributes:attr];
//NSLog( @"%@", text );
		}

		r.origin.y += s.height;
		if ( r.origin.y > max_sy ) { break; }


		i++;
	}


	{
		u32 outer = color_bg;
		u32 inner = n_bmp_alpha_replace_pixel( color_bg, 0 );

		n_bmp_ui_roundframe( &frame, 0,0,sx,sy, 8, 4, outer, inner );

		NSImage *img = n_mac_image_nbmp2nsimage( &frame );
		[img drawInRect:rect];
	}


	{
		u32 outer = color_frame;
		u32 inner = n_bmp_white_invisible;

		n_bmp_ui_roundframe( &frame, 0,0,sx,sy, 8, 2, outer, inner );

		NSImage *img = n_mac_image_nbmp2nsimage( &frame );
		[img drawInRect:rect];
	}


	n_bmp_free( &frame );

}


- (void) mouseUp:(NSEvent*) theEvent
{
//NSLog( @"mouseUp" );

	CGPoint pt_cur = [theEvent locationInWindow];

	CGFloat dx = fabs( pt_press.x - pt_cur.x );
	CGFloat dy = fabs( pt_press.y - pt_cur.y );
//NSLog( @"%f %f", pt_press.y, pt_cur.y );

	const CGFloat threshold = 4;

	if ( ( dx < threshold )&&( dy < threshold ) )
	{
		NSPoint event_location = [theEvent locationInWindow];
		NSPoint local_point    = [self convertPoint:event_location fromView:nil];

		n_focus = trunc( scroll + trunc( ( local_point.y - 4 ) / font_size.height ) );
//NSLog( @"%f", focus );

		[self display];
	}
	

	[delegate_doubleclick mouseUp:theEvent];

}

- (void) mouseDown:(NSEvent*) theEvent
{
//NSLog(@"mouseDown");

	pt = pt_press = [theEvent locationInWindow];

}

- (void) mouseDragged:(NSEvent*) theEvent
{
//NSLog(@"mouseDragged");

	CGPoint pt_cur = [theEvent locationInWindow];

	CGFloat dy = pt.y - pt_cur.y;

	pt = pt_cur;
//NSLog(@"%f %f", dx, dy);

	scroll -= dy / font_size.height;

	[self display];

}

- (void)scrollWheel:(NSEvent *)theEvent
{

	scroll -= [theEvent deltaY] / font_size.height;

	[self display];
 
}

@end




#endif // _H_NONNON_MAC_NONNON_LISTBOX



// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC
#define _H_NONNON_MAC




#import <Cocoa/Cocoa.h>




#include "../neutral/posix.c"




// [!] : shared

@protocol NonnonDragAndDrop_delegate

- (void) NonnonDragAndDrop_dropped : (NSString*) nsstr;

@end




void
n_mac_debug_count( void )
{

	static int i = 0;

	NSLog( @"%d", i );

	i++;


	return;
}




NSString*
n_mac_str2nsstring( n_posix_char *str )
{
	return [NSString stringWithUTF8String:str];
}

char*
n_mac_nsstring2str( NSString *nsstring )
{
	//return [nsstring cStringUsingEncoding:NSASCIIStringEncoding];
	return (void*) [nsstring UTF8String];
}




NSTimer*
n_mac_timer_init( id self, SEL selector, NSTimeInterval msec )
{

	// [x] : this hasn't precision like Win32

	NSTimer *timer = [NSTimer
		 scheduledTimerWithTimeInterval:msec / 1000
		                         target:self
		                       selector:selector
		                       userInfo:nil
		                        repeats:YES
	];

	timer.tolerance = 1 / 1000;

	return timer;
}

void
n_mac_timer_exit( NSTimer *timer )
{

	[timer invalidate];

	return;
}




void
n_mac_finder_call( NSString *path )
{
	NSArray *array = [NSArray arrayWithObjects:path, nil];
	[[NSWorkspace sharedWorkspace] activateFileViewerSelectingURLs:array];

	return;
}




BOOL
n_mac_is_darkmode( void )
{
	NSString *interfaceStyle = [NSUserDefaults.standardUserDefaults valueForKey:@"AppleInterfaceStyle"];
	return [interfaceStyle isEqualToString:@"Dark"];
}




void
n_mac_desktop_size( CGFloat *sx, CGFloat *sy )
{

	NSRect rect = [[NSScreen mainScreen] frame];

	if ( sx != NULL ) {  (*sx) = NSWidth( rect ); }
	if ( sy != NULL ) {  (*sy) = NSWidth( rect ); }


	return;
}




#endif // _H_NONNON_MAC



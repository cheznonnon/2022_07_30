// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File


// [!] : Usage
//
//	1 : replace your NSTextField to NonnonTextField
//	2 : IB : right pane : "Custom Class", "Class", set "NonnonTextField"
//	3 : IB : right pane : "Editable" to "None"
//	4 : modify behavior




#ifndef _H_NONNON_MAC_NONNON_TEXTFIELD
#define _H_NONNON_MAC_NONNON_TEXTFIELD




#import <Cocoa/Cocoa.h>




@interface NonnonTextField : NSTextField
@end


@interface NonnonTextField () <NSTextFieldDelegate>
@end


@implementation NonnonTextField


- (void) drawRect : (NSRect) dirtyRect
{

	[super drawRect:dirtyRect];

}


- init
{
//NSLog(@"init");

	self = [super init];

	if ( self )
	{
		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];
		[self setDelegate: self];
	}

	return self;
}

- (id) initWithCoder : (NSCoder*) decoder
{

	self = [super initWithCoder:decoder];

	if ( self )
	{
		[self registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeFileURL]];
		[self setDelegate: self];
		
		[self setStringValue:@"Drop Here"];
	}

	return self;
}

- (void) controlTextDidChange : (NSNotification*) obj
{
//NSLog( @"%@", self.stringValue );

	//[self setStringValue:@""];

}


-(NSDragOperation) draggingEntered:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingEntered" );

	// [!] : call when hovered

	return NSDragOperationCopy;
}

-(void) draggingExited:( id <NSDraggingInfo> )sender
{
//NSLog( @"draggingExited" );
}

-(BOOL) prepareForDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"prepareForDragOperation" );

	return YES;
}

-(BOOL) performDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"performDragOperation" );

	return YES;
}

-(void) concludeDragOperation:( id <NSDraggingInfo> )sender
{
//NSLog( @"concludeDragOperation" );

	//[self setStringValue:@""];

	NSPasteboard *pasteboard = [sender draggingPasteboard];
	NSString     *nsstr      = [[NSURL URLFromPasteboard:pasteboard] path];

	[self setStringValue:nsstr];

}

-(NSDragOperation) draggingUpdated:( id <NSDraggingInfo> ) sender
{
//NSLog( @"draggingUpdated" );

	return NSDragOperationCopy;
}

@end




#endif // _H_NONNON_MAC_NONNON_TEXTFIELD



// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lole32




#include <windows.h>
#include <shlobj.h>


#include "../../../nonnon/neutral/string.c"




int
main( void )
{

	HRESULT hr;


	IDataObject    *n_IDataObject    = NULL;
	IEnumFORMATETC *n_IEnumFORMATETC = NULL;


	hr = OleGetClipboard( &n_IDataObject );
	if ( FAILED( hr ) )
	{
n_posix_debug_literal( "OleGetClipboard()" );

		return 1;
	}


	hr = n_IDataObject->lpVtbl->EnumFormatEtc( n_IDataObject, DATADIR_GET, &n_IEnumFORMATETC );
	if ( FAILED( hr ) )
	{
n_posix_debug_literal( "IDataObject->EnumFormatEtc()" );

		n_IDataObject->lpVtbl->Release( n_IDataObject );

		return 1;
	}


	while( 1 )
	{

		FORMATETC fe;

		hr = n_IEnumFORMATETC->lpVtbl->Next( n_IEnumFORMATETC, 1, &fe, NULL );
		if ( hr != S_OK ) { break; }


		// while idling
		//
		//	13 : CF_UNICODETEXT
		//	16 : CF_LOCALE
		//	 1 : CF_TEXT
		//	 7 : CF_OEMTEXT

		// when file/folder is copied
		//
		//	-- : DataObject
		//	-- : Shell IDList Array
		//	15 : CF_HDROP
		//	-- : Preferred DropEffect
		//	-- : Shell Object Offsets
		//	-- : FileName
		//	-- : FileNameW
		//	-- : Ole Private Data

		n_posix_char str[ MAX_PATH ]; n_string_zero( str, MAX_PATH );

	   	GetClipboardFormatName( fe.cfFormat, str, MAX_PATH );
		n_posix_debug_literal( "%d : %s", fe.cfFormat, str );

	}


	n_IEnumFORMATETC->lpVtbl->Release( n_IEnumFORMATETC );



	n_IDataObject->lpVtbl->Release( n_IDataObject );


	return 0;
}


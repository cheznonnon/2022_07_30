//
//  main.m
//  Marie for Mac
//
//  Created by nonnon on 2022/07/05.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	@autoreleasepool {
	    // Setup code that might create autoreleased objects goes here.
	}
	return NSApplicationMain(argc, argv);
}

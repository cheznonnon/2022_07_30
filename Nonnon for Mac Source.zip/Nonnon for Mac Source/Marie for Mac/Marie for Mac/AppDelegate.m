//
//  AppDelegate.m
//  Marie for Mac
//
//  Created by nonnon on 2022/07/05.
//

#import "AppDelegate.h"


#import "../../nonnon/mac/image.c"
#import "../../nonnon/mac/n_imageview.c"
#import "../../nonnon/mac/n_scrollview.c"
#import "../../nonnon/mac/window.c"




@interface AppDelegate () <NonnonDragAndDrop_delegate>

@property (strong) IBOutlet NSWindow *window;

@property (strong) NonnonImageView  *imageview;
@property (strong) NonnonScrollView *scroll;

@end


@implementation AppDelegate

- (void) NonnonDragAndDrop_dropped:(NSString*)nsstr; {
    
//NSLog( @"dropped : %@", nsstr );

	NSImage *n_image = n_mac_image_path2nsimage( n_mac_nsstring2str( nsstr ), 256, n_bmp_black );
	if ( n_image == nil )
	{
//NSLog( @"dropped : nil" );
		[self n_marie4mac_drophere];
	} else {
		n_mac_window_image2window( _imageview, n_image, _window, _scroll, 256, 0.8 );
  	}
  	
	n_mac_window_centering( _window );
	
}


- (void) n_marie4mac_drophere
{

	u32 accent = n_bmp_color_mac( n_mac_nscolor2argb( [NSColor controlAccentColor] ) );

	u32 bg;
	if ( n_mac_is_darkmode() )
	{
		bg = n_bmp_black;
	} else {
		bg = n_bmp_white;
	}

	n_bmp bmp; n_bmp_zero( &bmp ); n_bmp_new( &bmp, 256,256 );
	n_bmp_flush_gradient( &bmp, bg, accent, N_BMP_GRADIENT_VERTICAL );
            
	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:@"manekineko_1" ofType:@"png"];
//NSLog( @"%@", path );
//NSLog( @"%s", n_mac_nsstring2str( path ) );

	n_bmp neko; n_bmp_zero( &neko );
	n_png_png2bmp( n_mac_nsstring2str( path ), &neko );
	n_bmp_mac( &neko );
	n_bmp_blendcopy( &neko, &bmp, 0,0,256,256, 0,0, 0.5 );
	n_bmp_free( &neko );


	NSString *text  = @"Drop Here";
	NSFont   *font  = [NSFont fontWithName:@"Trebuchet MS" size:32];
	u32       cmain = n_bmp_white;
	u32       ccntr = n_bmp_rgb( 10,10,10 );

	int mode = N_MAC_IMAGE_TEXT_CENTER | N_MAC_IMAGE_TEXT_SINK;
	n_mac_image_text( &bmp, text, font, cmain, ccntr, 2, 0,0,  mode );


	NSImage *n_image = n_mac_image_nbmp2nsimage( &bmp );

	n_mac_window_image2window( _imageview, n_image, _window, _scroll, 256, 0.8 );

/*
// [Needed] : turn sandbox off via "Entitlement"
//
//	saved location
//	File -> Project Settings -> grayed circle -> Finder -> DerivedData

n_bmp b; n_bmp_zero( &b );
n_mac_image_nsimage2nbmp( n_image, &b );
n_bmp_save_literal( &b, "test2.bmp" );
n_bmp_free( &b );
*/

	n_bmp_free( &bmp );


	return;
}


- (void)mouseUp:(NSEvent *)theEvent
{

	if ( [theEvent clickCount] == 2 )
	{

//CGPoint point = [theEvent locationInWindow];
//NSLog(@"Double click on: %f, %f", point.x, point.y);

		n_mac_window_centering( _window );
	
	}

}


- (void)awakeFromNib
{
	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}


- (void)applicationWillFinishLaunching:(NSNotification *)aNotification {

	_imageview = n_mac_nonnon_imageview ( self, _window, 0,0,256,256 );
	_scroll    = n_mac_nonnon_scrollview( self, _window, _imageview );

	[self n_marie4mac_drophere];

	n_mac_window_centering( _window );

}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


@end

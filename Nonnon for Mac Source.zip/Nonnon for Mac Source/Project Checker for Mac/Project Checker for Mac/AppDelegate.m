//
//  AppDelegate.m
//  Project Checker for Mac
//
//  Created by のんのん on 2022/07/06.
//

#import "AppDelegate.h"


#include "../../nonnon/mac/n_listbox.c"
#include "../../nonnon/mac/n_textfield.c"

#include "../../nonnon/mac/_mac.c"

#include "../../nonnon/neutral/dir.c"
#include "../../nonnon/neutral/txt.c"

#include "./engine.c"




@interface AppDelegate ()

@property (weak) IBOutlet NonnonListbox *n_list;

@property (weak) IBOutlet NSButton *n_button_reverse;
@property (weak) IBOutlet NSButton *n_button_go;

@property (weak) IBOutlet NonnonTextField *n_text_fr;
@property (weak) IBOutlet NonnonTextField *n_text_to;

@property (strong) IBOutlet NSWindow *window;

@property n_txt n_txt;

@end




@implementation AppDelegate


@synthesize n_txt;


- (instancetype)init
{
	self = [super init];
	if ( self )
	{
		n_txt_zero( &n_txt ); n_txt_new( &n_txt );
	}
	
	return self;
}


- (void) n_list_txt_set:(n_posix_char*)str
{
	n_txt_free( &n_txt ); n_txt_new( &n_txt );
	n_txt_set( &n_txt, 0, str );

	[_n_list n_reset];
	[_n_list display];
}


- (IBAction)n_button_reverse_pressed:(id)sender {

	NSString *tmp = [[_n_text_fr stringValue] copy];
	[_n_text_fr setStringValue:[_n_text_to stringValue]];
	[_n_text_to setStringValue:tmp];

}

- (IBAction)n_button_go:(id)sender {

	NSString *f = [_n_text_fr stringValue];
	NSString *t = [_n_text_to stringValue];

	if ( ( [f length] == 0 )||( [t length] == 0 ) )
	{
		[self n_list_txt_set:"Please Check"];
		return;
	}


	NSFileManager *fm = [NSFileManager defaultManager];

	BOOL is_dir_f;
	BOOL exists_f = [fm fileExistsAtPath:f isDirectory:&is_dir_f];

	BOOL is_dir_t;
	BOOL exists_t = [fm fileExistsAtPath:t isDirectory:&is_dir_t];

	if ( ( exists_f == FALSE )||( exists_t == FALSE ) )
	{
		[self n_list_txt_set:"Please Check"];
		return;
	}
	
	if ( is_dir_f != is_dir_t )
	{
		[self n_list_txt_set:"Please Check"];
		return;
	}
	
	if ( is_dir_f )
	{
//NSLog( @"Folders" );

		n_posix_char *str_f = n_mac_nsstring2str( f );
		n_posix_char *str_t = n_mac_nsstring2str( t );

		n_txt_free( &n_txt ); n_txt_new( &n_txt );
		n_pc_go_folder( &n_txt, str_f, str_t, n_posix_false, n_posix_true );
		n_pc_sort( &n_txt );

		[_n_list n_reset];
		[_n_list display];

//n_txt_save( &txt, "ret.txt" );

	} else {

		BOOL is_same = [fm contentsEqualAtPath:f andPath:t];
//NSLog( @"is_same : %d", is_same );

		if ( is_same )
		{
			[self n_list_txt_set:"same binary"];
		} else {
			[self n_list_txt_set:"different binary"];
		}
		
	}
	
}


- (void)mouseUp:(NSEvent *)theEvent
{

	if ( [theEvent clickCount] == 2 )
	{
//NSLog( @"double clicked" );

		n_type_int focus = _n_list.n_focus;

		n_posix_char *item = n_string_carboncopy( n_txt_get( &n_txt, focus ) );
		if ( 4 > n_posix_strlen( item ) ) { return; }


		NSString *nsstr_f = [_n_text_fr stringValue];
		NSString *nsstr_t = [_n_text_to stringValue];
	
		n_posix_char *f = n_mac_nsstring2str( nsstr_f );
		n_posix_char *t = n_mac_nsstring2str( nsstr_t );

 
		// [!] : don't use n_string_path_name()
		//
		//	this will be relative path

		n_posix_char *name = n_string_path_carboncopy( item );

		n_string_copy( &item[ 4 ], item );
		n_string_copy( &item[ n_posix_strlen( t ) ], name );

		n_string_free( item );


		n_posix_char *f2 = n_string_path_cat( f, name, NULL );
		n_posix_char *t2 = n_string_path_cat( t, name, NULL );

		n_string_path_free( f ); f = f2;
		n_string_path_free( t ); t = t2;

		n_mac_finder_call( n_mac_str2nsstring( f ) );
		n_mac_finder_call( n_mac_str2nsstring( t ) );
	
	}

}


- (void)awakeFromNib
{
	_n_list.delegate_doubleclick =  self;
	_n_list.n_txt                = &n_txt;

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];
}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


@end
